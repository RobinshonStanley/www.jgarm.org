import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

/// Canonical image paths for ministry/event/get-involved placeholders.
/// Reuse these constants wherever the same card appears so its photograph
/// remains identical across every page and repeated presentation.
class JgarmImageAssets {
  static const String sundaySchool = 'assets/sunday_school.jpg';
  static const String worshipMinistry = 'assets/worship_ministry.jpg';
  static const String sundayFellowship = 'assets/fellowship.jpg';
  static const String serveWithUs = 'assets/outreach_ministry.jpg';
  static const String prayerMeeting = 'assets/prayer.jpg';
  static const String youthServices = 'assets/youth_ministry.jpg';
  static const String compassionCommunity = 'assets/compassion_community_transformation.jpg';
  static const String growWithUs = 'assets/grow_with_us.jpg';
  static const String joinUs = 'assets/join_us.jpg';
  static const String supportGhcc = 'assets/ghcc_children_1.jpg';
  static const String ghccPhoto = 'assets/ghcc_children_1.jpg';
  static const String theChurch = 'assets/the_church.jpg';
  static const String prayerRequests = 'assets/prayer_requests.jpg';
}

class JgarmColors {
  static const Color lightBlue = Color(0xFFA5CEEE);
  static const Color pink = Color(0xFFCC5F90);
  static const Color darkBlue = Color(0xFF173F68);
  static const Color headerNavy = Color(0xFF1E3A5F);
  static const Color headerGold = Color(0xFFC9A227);
  static const Color royalBlue = Color(0xFF245A86);
  static const Color amber = Color(0xFFF0B33D);
  static const Color softAmber = Color(0xFFFFF4D8);
  static const Color darkPink = Color(0xFFA84770);
  static const Color paleBlue = Color(0xFFF3F9FD);
  static const Color veryLightBlue = Color(0xFFEAF5FC);
  static const Color white = Colors.white;
}

Widget _jgarmChurchEmblem({double size = 76}) {
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [JgarmColors.headerNavy, JgarmColors.royalBlue],
      ),
      border: Border.all(color: JgarmColors.headerGold, width: 3),
      boxShadow: const [
        BoxShadow(color: Color(0x30000000), blurRadius: 9, offset: Offset(0, 4)),
      ],
    ),
    child: Stack(
      alignment: Alignment.center,
      children: [
        Icon(Icons.church_rounded, size: size * 0.62, color: Colors.white),
        Positioned(
          top: size * 0.08,
          child: Icon(Icons.add, size: size * 0.25, color: JgarmColors.softAmber),
        ),
      ],
    ),
  );
}

void main() {
  runApp(const JgarmWebsite());
}

class JgarmWebsite extends StatelessWidget {
  const JgarmWebsite({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JGARM | Jesus Grace and Restoration Ministry',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: JgarmColors.veryLightBlue,
        colorScheme: ColorScheme.fromSeed(
          seedColor: JgarmColors.darkBlue,
          primary: JgarmColors.darkBlue,
          secondary: JgarmColors.amber,
          surface: Colors.white,
        ),
      ),
      home: const JgarmHomePage(),
    );
  }
}

class JgarmHomePage extends StatefulWidget {
  const JgarmHomePage({super.key});

  @override
  State<JgarmHomePage> createState() => _JgarmHomePageState();
}

class _JgarmHomePageState extends State<JgarmHomePage> {
  int selectedIndex = 0;

  final List<String> menuItems = [
    'Home',
    'About',
    'Leadership',
    'Ministries',
    'Services',
    'Sermons',
    'Events',
    'Prayer',
    'Grace Home',
    'Give',
    'Contact',
    'Get Involved',
  ];

  final List<Map<String, String>> leadership = [
    {
      'name': 'Bishop Robinshon Onyango Stanley',
      'position': 'Founder, Vision Bearer & Chairman',
      'photo': 'assets/chairman_photo.jpg',
      'message':
          'Our vision is to make as many disciples as possible, preaching the Gospel of Jesus Christ and bringing hope, restoration, and transformation to lives.',
    },
    {
      'name': 'Richard Orina Oyungu',
      'position': 'Assistant Chairperson & Kisii Regional Overseer',
      'photo': 'assets/asschair_photo.jpg',
      'message':
          'Let us stand together in unity, serve faithfully, and strengthen the work of God in every community entrusted to us.',
    },
    {
      'name': 'Lilian Onyango',
      'position': 'Women Leader',
      'photo': 'assets/womenleader_photo.jpg',
      'message':
          'Women of God, let us rise in faith, prayer, love, and service, nurturing families and raising a generation that honours Christ.',
    },
    {
      'name': 'Maureen Adhiambo',
      'position': 'Treasurer',
      'photo': 'assets/treasurer_photo.jpg',
      'message':
          'Let us be faithful stewards of every resource God provides, serving with honesty, transparency, and a heart of generosity.',
    },
    {
      'name': 'Pastor John Obote',
      'position': 'Secretary',
      'photo': 'assets/secretary_photo.jpg',
      'message':
          'Let everything be done decently and in order, with faithfulness, wisdom, and commitment to the mission of Christ.',
    },
    {
      'name': 'Rolex Odhiambo',
      'position': 'Instruments Department Leader',
      'photo': 'assets/instrumentleader_photo.jpg',
      'message':
          'Let every instrument and every sound glorify God, lead His people into worship, and proclaim the goodness of Jesus Christ.',
    },
    {
      'name': "Pastor Tobias K'agolla",
      'position': 'JGARM Coordinator',
      'photo': 'assets/coordinator_photo.jpg',
      'message':
          'Together, let us coordinate our efforts in love and unity, ensuring that the vision of JGARM reaches every soul and community.',
    },
  ];

  void _selectPage(int index) {
    setState(() {
      selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Column(
        children: [
          _horizontalNavigationBar(),
          _officialCoverBanner(),
          Expanded(child: _buildPage()),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(96),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 44,
            width: double.infinity,
            color: const Color(0xFFA5CEEE),
            child: Image.asset(
              'assets/jgarm_letterhead_skyblue.jpg',
              width: double.infinity,
              fit: BoxFit.fill,
              errorBuilder: (_, __, ___) => const Center(
                child: Text('JESUS GRACE AND RESTORATION MINISTRY', textAlign: TextAlign.center,
                  style: TextStyle(color: JgarmColors.darkBlue, fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ),
          ),
          Container(
            height: 52,
            width: double.infinity,
            color: JgarmColors.headerNavy,
            child: Row(
              children: [
                SizedBox(
                  width: 76,
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: IconButton(
                      tooltip: 'Back to Home',
                      padding: const EdgeInsets.only(left: 12),
                      onPressed: () => _selectPage(0),
                      icon: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          'JESUS GRACE AND RESTORATION MINISTRY',
                          maxLines: 1,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.25,
                          ),
                        ),
                      ),
                      const SizedBox(height: 2),
                      const FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          'THE FIRE OF THE GOSPEL ABLAZE',
                          maxLines: 1,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.55,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 76,
                  child: Builder(
                    builder: (context) => TextButton(
                      onPressed: () => Scaffold.of(context).openDrawer(),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(76, 48),
                      ),
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.menu, size: 19),
                          Text('MENU', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.6)),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _horizontalNavigationBar() {
    final labels = [
      'HOME', 'ABOUT US', 'LEADERSHIP', 'MINISTRIES', 'SERVICES',
      'SERMONS', 'EVENTS', 'PRAYER', 'GRACE HOME', 'GIVE', 'CONTACT',
      'GET INVOLVED',
    ];

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: JgarmColors.lightBlue.withOpacity(0.8)),
        ),
        boxShadow: const [
          BoxShadow(color: Color(0x10000000), blurRadius: 5, offset: Offset(0, 2)),
        ],
      ),
      child: SizedBox(
        height: 48,
        child: Center(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(menuItems.length, (index) {
                final active = selectedIndex == index;
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextButton(
                      onPressed: () => _selectPage(index),
                      style: TextButton.styleFrom(
                        foregroundColor: active ? JgarmColors.pink : JgarmColors.darkBlue,
                        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                      ),
                      child: Text(
                        labels[index],
                        style: TextStyle(
                          fontSize: 11,
                          letterSpacing: 0.35,
                          fontWeight: active ? FontWeight.w800 : FontWeight.w700,
                        ),
                      ),
                    ),
                    if (index != menuItems.length - 1)
                      const Text('|', style: TextStyle(color: JgarmColors.lightBlue, fontSize: 13)),
                  ],
                );
              }),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    JgarmColors.lightBlue,
                    JgarmColors.veryLightBlue,
                  ],
                ),
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/jgarmchurch_logo.jpg',
                    height: 100,
                    width: 100,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) {
                      return _jgarmChurchEmblem(size: 88);
                    },
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'JGARM CHURCH',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: JgarmColors.darkBlue,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'The Fire of the Gospel Ablaze',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: JgarmColors.pink,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: menuItems.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: Icon(
                      _menuIcon(index),
                      color: selectedIndex == index
                          ? JgarmColors.pink
                          : JgarmColors.darkBlue,
                    ),
                    title: Text(
                      menuItems[index],
                      style: TextStyle(
                        color: selectedIndex == index
                            ? JgarmColors.pink
                            : JgarmColors.darkBlue,
                        fontWeight: selectedIndex == index
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                    selected: selectedIndex == index,
                    onTap: () {
                      _selectPage(index);
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _menuIcon(int index) {
    switch (index) {
      case 0:
        return Icons.home;
      case 1:
        return Icons.info_outline;
      case 2:
        return Icons.people_alt;
      case 3:
        return Icons.church;
      case 4:
        return Icons.menu_book;
      case 5:
        return Icons.play_circle_outline;
      case 6:
        return Icons.event;
      case 7:
        return Icons.volunteer_activism;
      case 8:
        return Icons.child_care;
      case 9:
        return Icons.favorite;
      case 10:
        return Icons.contact_mail;
      case 11:
        return Icons.handshake;
      default:
        return Icons.circle;
    }
  }

  Widget _buildPage() {
    switch (selectedIndex) {
      case 0:
        return _homePage();
      case 1:
        return _aboutPage();
      case 2:
        return _leadershipPage();
      case 3:
        return _ministriesPage();
      case 4:
        return _servicesPage();
      case 5:
        return _sermonsPage();
      case 6:
        return _eventsPage();
      case 7:
        return _prayerPage();
      case 8:
        return _ghccPage();
      case 9:
        return _givePage();
      case 10:
        return _contactPage();
      case 11:
        return _getInvolvedPage();
      default:
        return _homePage();
    }
  }

  Widget _homePage() {
    return SingleChildScrollView(
      child: Column(
        children: [
          JgarmLeadershipCarousel(leaders: leadership),
          const JgarmUpdatesCarousel(),
          _sectionTitle(
            'Welcome to JGARM Church',
            'Jesus Grace And Restoration Ministry',
          ),
          _visionMissionSection(),
          _bishopMinistrySection(),
          _ministryHighlight(),
          _compassionHighlight(),
          _churchHighlight(),
          _prayerHighlight(),
          _fellowshipHighlight(),
          _servicesPreview(),
          const ProgrammePreview(),
          _mediaPreview(),
          _quickAccess(),
          const ContactFooter(),
        ],
      ),
    );
  }

  Widget _officialCoverBanner() {
    // Keep the original permanent banner artwork intact, but display it at a
    // more restrained width so it no longer dominates the vertical layout.
    return Container(
      width: double.infinity,
      color: JgarmColors.darkBlue,
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Center(
        child: FractionallySizedBox(
          widthFactor: 0.88,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1120),
            child: Image.asset(
              'assets/jgarm_official_cover_banner.jpg',
              width: double.infinity,
              fit: BoxFit.contain,
              semanticLabel: 'Official JGARM ministry cover banner',
              errorBuilder: (_, __, ___) => Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                color: JgarmColors.darkBlue,
                child: const Text(
                  'JESUS GRACE AND RESTORATION MINISTRY',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 45, 20, 25),
      child: Column(
        children: [
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: JgarmColors.pink,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _visionMissionSection() {
    final pillars = [
      _visionPillar(Icons.center_focus_strong, 'Christ at the Centre',
          'Jesus Christ is the foundation and focal point of our worship, teaching, leadership, fellowship and spiritual growth.',
          imagePath: 'assets/giphy.gif'),
      _visionPillar(Icons.public, 'Gospel Outreach',
          'We proclaim the Gospel of Jesus Christ, reaching the lost and carrying the message of salvation to our communities and beyond.',
          imagePath: 'assets/gospel_outreach.jpg'),
      _visionPillar(Icons.menu_book, 'Discipleship and Equipping',
          'We make mature disciples who grow in faith, live by God’s Word, discover their gifts and become equipped for ministry and service.',
          imagePath: 'assets/discipleship_equipping.jpg'),
      _visionPillar(Icons.volunteer_activism, 'Compassion and Community Transformation',
          'We demonstrate Christ’s love through practical care, generosity, restoration and service, bringing hope to individuals, families and communities.'),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
      child: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(26),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [JgarmColors.darkBlue, Color(0xFF315D7D)]),
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: Color(0x26000000), blurRadius: 12, offset: Offset(0, 5))],
          ),
          child: Column(children: [
            SizedBox(
              width: 132,
              height: 112,
              child: Image.asset(
                'assets/jgarm_flapping_dove.webp',
                fit: BoxFit.contain,
                gaplessPlayback: true,
                semanticLabel: 'Animated white dove carrying a red rose',
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
            const SizedBox(height: 10),
            Text('OUR VISION', style: TextStyle(color: JgarmColors.softAmber, fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 2)),
            SizedBox(height: 12),
            Text('Christ at the Centre. Disciples for the Nations. Love in Action.', textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 23, height: 1.3, fontWeight: FontWeight.w800)),
            SizedBox(height: 14),
            Text('To be a Christ-centred, Spirit-empowered ministry committed to proclaiming the Gospel to all nations, making and equipping devoted disciples of Jesus Christ, and transforming lives and communities through His love, compassion and service—to the glory of God.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 15, height: 1.65)),
          ]),
        ),
        const SizedBox(height: 22),
        Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 12,
          runSpacing: 6,
          children: [
            const Text(
              'THE FOUR PILLARS OF OUR VISION',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: JgarmColors.darkBlue,
                fontSize: 19,
                fontWeight: FontWeight.w800,
                letterSpacing: .6,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        LayoutBuilder(builder: (context, constraints) {
          // Use naturally sized cards instead of a fixed-height grid. This lets
          // the descriptions wrap and grow on small screens without overflow.
          final columns = constraints.maxWidth >= 1100
              ? 4
              : (constraints.maxWidth >= 620 ? 2 : 1);
          final spacing = 14.0;
          final cardWidth = columns == 1
              ? constraints.maxWidth
              : (constraints.maxWidth - spacing * (columns - 1)) / columns;
          return Wrap(
            spacing: spacing,
            runSpacing: spacing,
            children: pillars
                .map((pillar) => SizedBox(width: cardWidth, child: pillar))
                .toList(),
          );
        }),
        const SizedBox(height: 18),
        _homeContentCard(icon: Icons.campaign, title: 'Our Mission',
          text: 'To preach the gospel of the cross of Jesus, evangelise and baptise, thus winning many souls to Christ.',
          scripture: 'Matthew 28:19–20',
          imagePath: 'assets/our_mission.jpg'),
      ]),
    );
  }

  Widget _visionPillar(IconData icon, String title, String description, {String? imagePath}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: JgarmColors.softAmber, width: 1.2),
        boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 7, offset: Offset(0, 3))]),
      child: Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.start, children: [
        if (imagePath != null) ...[
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.asset(imagePath, width: double.infinity, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: JgarmColors.veryLightBlue,
                  alignment: Alignment.center, child: Icon(icon, size: 42, color: JgarmColors.darkBlue))),
            ),
          ),
        ] else
          Container(width: 58, height: 58, decoration: const BoxDecoration(shape: BoxShape.circle,
            gradient: LinearGradient(colors: [JgarmColors.darkBlue, Color(0xFF315D7D)])),
            child: Icon(icon, color: JgarmColors.softAmber, size: 31)),
        const SizedBox(height: 12),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(color: JgarmColors.darkBlue, fontWeight: FontWeight.w800, fontSize: 17, height: 1.25)),
        const SizedBox(height: 9),
        Text(description, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black87, height: 1.5, fontSize: 15)),
      ]),
    );
  }

  Widget _bishopMinistrySection() {
  return Container(
    width: double.infinity,
    margin: const EdgeInsets.all(20),
    padding: const EdgeInsets.all(25),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [
          JgarmColors.darkBlue,
          Color(0xFF477895),
        ],
      ),
      borderRadius: BorderRadius.circular(20),
    ),
    child: LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 700;

        final image = ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Image.asset(
            'assets/bishop_preaching.jpg',
            height: mobile ? 260 : 300,
            width: mobile ? double.infinity : 280,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) {
              return Container(
                height: mobile ? 260 : 300,
                width: 280,
                color: JgarmColors.lightBlue,
                child: const Icon(
                  Icons.person,
                  size: 100,
                  color: Colors.white,
                ),
              );
            },
          ),
        );

        final text = Column(
          crossAxisAlignment: mobile
              ? CrossAxisAlignment.center
              : CrossAxisAlignment.start,
          children: [
            const Text(
              'Our Founder & Vision Bearer',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: JgarmColors.lightBlue,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Bishop Robinshon Onyango Stanley',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Founder, Vision Bearer & Chairman',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: JgarmColors.lightBlue,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Serving JGARM with a vision to make as many disciples as possible, preaching the Gospel of Jesus Christ and bringing restoration and hope to lives.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                height: 1.6,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              '“The Fire of the Gospel Ablaze”',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: JgarmColors.pink,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        );

        if (mobile) {
          return Column(
            children: [
              image,
              const SizedBox(height: 25),
              text,
            ],
          );
        }

        return Row(
          children: [
            image,
            const SizedBox(width: 35),
            Expanded(child: text),
          ],
        );
      },
    ),
  );
}
                  
  
  Widget _leadershipHomeSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 40,
      ),
      color: JgarmColors.paleBlue,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            'Our Leadership',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            'Serving God, His Church and His people',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.pink,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 28),

          LayoutBuilder(
            builder: (context, constraints) {
              int columns = 1;

              if (constraints.maxWidth >= 1100) {
                columns = 3;
              } else if (constraints.maxWidth >= 700) {
                columns = 2;
              }

              const spacing = 18.0;

              final cardWidth =
                  (constraints.maxWidth -
                          (spacing * (columns - 1))) /
                      columns;

              return Wrap(
                alignment: WrapAlignment.center,
                spacing: spacing,
                runSpacing: spacing,
                children: List.generate(
                  leadership.length,
                  (index) {
                    return SizedBox(
                      width: cardWidth,
                      child: _leadershipCard(
                        leadership[index],
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _leadershipCard(
    Map<String, String> leader,
  ) {
    return Card(
      elevation: 4,
      margin: EdgeInsets.zero,
      color: Colors.white,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(
          color: JgarmColors.lightBlue,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment:
              CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius:
                  BorderRadius.circular(14),
              child: Container(
                height: 220,
                width: double.infinity,
                color: JgarmColors.veryLightBlue,
                child: Image.asset(
                  leader['photo']!,
                  fit: BoxFit.contain,
                  alignment: Alignment.center,
                  errorBuilder: (_, __, ___) {
                    return Center(
                      child: Container(
                        width: 112,
                        height: 112,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [JgarmColors.darkBlue, Color(0xFF315D7D)]),
                        ),
                        child: const Icon(Icons.person, size: 66, color: JgarmColors.softAmber),
                      ),
                    );
                  },
                ),
              ),
            ),

            const SizedBox(height: 14),

            Text(
              leader['name']!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: JgarmColors.darkBlue,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 6),

            Text(
              leader['position']!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: JgarmColors.pink,
                fontWeight: FontWeight.bold,
                fontSize: 13,
                height: 1.4,
              ),
            ),

            const SizedBox(height: 12),

            Text(
              '“${leader['message']!}”',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.black87,
                fontSize: 13,
                height: 1.5,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }

       

  Widget _ministryHighlight() {
    return _homeContentCard(
      icon: Icons.menu_book,
      title: 'The Ministry',
      imagePath: 'assets/the_ministry.png',
      text:
          'Therefore, seeing we have this ministry, as we have received mercy, we faint not. JGARM is committed to faithfully carrying the Gospel of Jesus Christ to people and communities.',
      scripture: '2 Corinthians 4:1–6',
    );
  }

  Widget _compassionHighlight() {
    return _homeContentCard(
      icon: Icons.volunteer_activism,
      title: 'Compassion & Community Transformation',
      imagePath: JgarmImageAssets.compassionCommunity,
      text: 'Serving people with practical compassion, sharing the hope of Christ and strengthening our communities through love and faithful action.',
    );
  }

  Widget _churchHighlight() {
    return _homeContentCard(
      icon: Icons.church,
      imagePath: JgarmImageAssets.theChurch,
      title: 'The Church',
      text:
          'JGARM is a Christ-centred ministry where believers gather in worship, fellowship, teaching, prayer and service.',
    );
  }

  Widget _prayerHighlight() {
    return _homeContentCard(
      icon: Icons.volunteer_activism,
      title: 'Prayer',
      text:
          'We believe in the power of prayer and welcome individuals and families to bring their needs before God.',
      scripture: 'James 5:16',
      imagePath: JgarmImageAssets.prayerRequests,
    );
  }

  Widget _fellowshipHighlight() {
    return _homeContentCard(
      icon: Icons.groups,
      title: 'Fellowship',
      imagePath: JgarmImageAssets.sundayFellowship,
      text:
          'Believers grow together through teaching, fellowship, breaking of bread and prayer.',
      scripture: 'Acts 2:42',
    );
  }

  Widget _homeContentCard({
    required IconData icon,
    required String title,
    required String text,
    String? scripture,
    String? imagePath,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 10),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: JgarmColors.lightBlue,
        ),
        boxShadow: const [
          BoxShadow(
            blurRadius: 8,
            offset: Offset(0, 3),
            color: Color(0x18000000),
          ),
        ],
      ),
      child: Column(
        children: [
          if (imagePath != null) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Image.asset(
                  imagePath,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: JgarmColors.veryLightBlue, alignment: Alignment.center, child: Icon(icon, size: 48, color: JgarmColors.darkBlue)),
                ),
              ),
            ),
            const SizedBox(height: 14),
          ] else
            Container(
              width: 76, height: 76,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [JgarmColors.softAmber, JgarmColors.veryLightBlue]),
            ),
            child: Icon(icon, size: 42, color: JgarmColors.darkBlue),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 15,
              height: 1.6,
              color: Colors.black87,
            ),
          ),
          if (scripture != null) ...[
            const SizedBox(height: 12),
            Text(
              scripture,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: JgarmColors.pink,
                fontWeight: FontWeight.bold,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ],
      ),
    );
  }

  
    Widget _servicesPreview() {
  final services = [
    [
      'Sunday Service',
      'Sunday • 8:00 AM – 4:00 PM',
      Icons.church,
      'assets/jgarm_church_auditorium.png',
    ],
    [
      'Sisters’ / Women’s Ministry',
      'Tuesday • 2:00 PM – 4:00 PM',
      Icons.woman,
      'assets/women_ministry.jpg',
    ],
    [
      'Hospital Ministry',
      'Wednesday • Scheduled Visits',
      Icons.local_hospital,
      'assets/hospital_ministry.jpg',
    ],
    [
      'Men’s Teachings',
      'Thursday • 3:00 PM – 5:00 PM',
      Icons.man,
      'assets/mens_ministry_original.jpg',
    ],
    [
      'Prayer Meeting',
      'Friday • 5:00 PM – 7:00 PM',
      Icons.volunteer_activism,
      'assets/prayer_ministry.jpg',
    ],
    [
      'Youth Service',
      'Saturday • 2:00 PM – 5:00 PM',
      Icons.groups,
      'assets/youth_ministry.jpg',
    ],
  ];

  return Padding(
    padding: const EdgeInsets.all(20),
    child: Column(
      children: [
        _sectionTitle(
          'Our Services',
          'Gathering together in worship, teaching and fellowship',
        ),
        LayoutBuilder(
          builder: (context, constraints) {
            final columns = constraints.maxWidth >= 900
                ? 3
                : constraints.maxWidth >= 600
                    ? 2
                    : 1;

            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: services.length,
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                // Give photo-led cards enough vertical room on phones and desktops.
                childAspectRatio: 1.0,
              ),
              itemBuilder: (context, index) {
                return InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () {
                    setState(() {
                      selectedIndex = 3;
                    });
                  },
                  child: _featureCard(
                    icon: services[index][2] as IconData,
                    title: services[index][0] as String,
                    text: services[index][1] as String,
                    imagePath: services[index].length > 3
                        ? services[index][3] as String
                        : null,
                  ),
                );
              },
            );
          },
        ),
      ],
    ),
  );
}      

  Widget _featureCard({
    required IconData icon,
    required String title,
    required String text,
    String? imagePath,
  }) {
    return Card(
      elevation: 4,
      color: Colors.white,
      shadowColor: JgarmColors.darkBlue.withOpacity(0.14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: JgarmColors.amber, width: 1.2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            if (imagePath != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: double.infinity,
                  height: 104,
                  child: ColoredBox(
                    color: JgarmColors.veryLightBlue,
                    child: Image.asset(
                      imagePath,
                      fit: BoxFit.cover,
                      alignment: Alignment.center,
                    errorBuilder: (_, __, ___) => Container(
                      color: JgarmColors.veryLightBlue,
                      child: Icon(icon, size: 38, color: JgarmColors.darkBlue),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ] else
              Container(
                width: 68, height: 68,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [JgarmColors.softAmber, JgarmColors.veryLightBlue]),
              ),
              child: Icon(icon, size: 38, color: JgarmColors.darkBlue),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: JgarmColors.darkBlue,
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.black87,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _mediaPreview() {
    final videos = [
      {
        'title': 'JGARM Ministry',
        'description': 'Watch and connect with the ministry.',
        'url': 'https://youtu.be/UGhKYGsjjlI',
      },
      {
        'title': 'JGARM Worship & Ministry',
        'description': 'Experience the ministry and fellowship.',
        'url': 'https://youtu.be/m5Ouyi_ij6w',
      },
      {
        'title': 'JGARM Gospel Ministry',
        'description': 'Messages and ministry from JGARM.',
        'url': 'https://youtu.be/TsWEUTrYCHg',
      },
    ];

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _sectionTitle(
            'Media',
            'Watch, listen and connect with JGARM',
          ),
          LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 900
                  ? 3
                  : constraints.maxWidth >= 600
                      ? 2
                      : 1;

              return GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: videos.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.25,
                ),
                itemBuilder: (context, index) {
                  return _videoCard(
                    title: videos[index]['title']!,
                    description: videos[index]['description']!,
                    url: videos[index]['url']!,
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _videoCard({
    required String title,
    required String description,
    required String url,
  }) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.play_circle_fill,
              size: 58,
              color: JgarmColors.pink,
            ),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: JgarmColors.darkBlue,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              description,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 15),
            ElevatedButton.icon(
              onPressed: () async {
                final uri = Uri.parse(url);

                if (await canLaunchUrl(uri)) {
                  await launchUrl(
                    uri,
                    webOnlyWindowName: '_blank',
                  );
                }
              },
              icon: const Icon(Icons.play_arrow),
              label: const Text('WATCH'),
              style: ElevatedButton.styleFrom(
                backgroundColor: JgarmColors.darkBlue,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _quickAccess() {
    final items = [
      ['Prayer Request', Icons.volunteer_activism, 7],
      ['Give', Icons.favorite, 9],
      ['GHCC', Icons.child_care, 8],
      ['Contact Us', Icons.contact_mail, 10],
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(25),
      color: JgarmColors.veryLightBlue,
      child: Column(
        children: [
          const Text(
            'Quick Access',
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            children: items.map((item) {
              return ElevatedButton.icon(
                onPressed: () => _selectPage(item[2] as int),
                icon: Icon(item[1] as IconData),
                label: Text(item[0] as String),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: JgarmColors.darkBlue,
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _leadershipPage() {
    return SimplePage(
      title: 'Our Leadership',
      subtitle: 'Serving God, His Church and His people',
      icon: Icons.people_alt,
      child: _bishopLeadershipSection(),
    );
  }

  Widget _aboutPage() {
    return SimplePage(
      title: 'About JGARM',
      subtitle: 'Jesus Grace And Restoration Ministry',
      icon: Icons.info_outline,
      child: Column(
        children: [
          _visionMissionSection(),
          _bishopLeadershipSection(),
          _aboutSection(
            'The Ministry',
            'Therefore, seeing we have this ministry, as we have received mercy, we faint not. JGARM is committed to faithfully carrying the Gospel of Jesus Christ to people and communities.',
            Icons.menu_book,
            imagePath: 'assets/the_ministry.png',
          ),
          _aboutSection(
            'Compassion and Community Transformation',
            'We demonstrate the love of Christ through practical care, generosity, restoration and service, bringing hope to individuals, families and communities.',
            Icons.volunteer_activism,
            imagePath: JgarmImageAssets.compassionCommunity,
          ),
          _aboutSection(
            'The Church',
            'JGARM is a Christ-centred ministry where believers gather in worship, fellowship, teaching, prayer and service.',
            Icons.church,
            imagePath: JgarmImageAssets.theChurch,
          ),
          _aboutSection(
            'Prayer Requests',
            'We believe in the power of prayer and welcome individuals and families to bring their needs before God.',
            Icons.volunteer_activism,
            imagePath: JgarmImageAssets.prayerRequests,
          ),
          _aboutSection(
            'Fellowship',
            'Believers grow together through teaching, fellowship, breaking of bread and prayer.\n\nActs 2:42',
            Icons.groups,
            imagePath: JgarmImageAssets.sundayFellowship,
          ),
          const SizedBox(height: 15),
          const Text(
            '“The church is not a building; it is a community of believers growing together in Christ.”',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.pink,
              fontStyle: FontStyle.italic,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  
  Widget _bishopLeadershipSection() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(
        vertical: 15,
      ),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: JgarmColors.paleBlue,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: JgarmColors.lightBlue,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.center,
        children: [
          const Text(
            'Our Leadership',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            'Leadership dedicated to the mission and vision of JGARM',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.pink,
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 25),

          LayoutBuilder(
            builder: (context, constraints) {
              int columns = 1;

              if (constraints.maxWidth >= 900) {
                columns = 3;
              } else if (
                  constraints.maxWidth >= 600) {
                columns = 2;
              }

              const spacing = 16.0;

              final cardWidth =
                  (constraints.maxWidth -
                          spacing * (columns - 1)) /
                      columns;

              return Wrap(
                alignment: WrapAlignment.center,
                spacing: spacing,
                runSpacing: spacing,
                children: List.generate(
                  leadership.length,
                  (index) {
                    return SizedBox(
                      width: cardWidth,
                      child: _leadershipCard(
                        leadership[index],
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }

    
  Widget _aboutSection(
    String title,
    String text,
    IconData icon, {String? imagePath}
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: JgarmColors.lightBlue,
        ),
      ),
      child: Column(
        children: [
          if (imagePath != null) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Image.asset(imagePath, width: double.infinity, fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: JgarmColors.veryLightBlue, alignment: Alignment.center, child: Icon(icon, size: 42, color: JgarmColors.darkBlue))),
              ),
            ),
            const SizedBox(height: 12),
          ],
          Container(
            width: 62,
            height: 62,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [JgarmColors.darkBlue, Color(0xFF315D7D)],
              ),
            ),
            child: Icon(icon, color: JgarmColors.softAmber, size: 32),
          ),
          const SizedBox(height: 10),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 21,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(
              height: 1.6,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _ministriesPage() {
    final ministries = [
      [
        'Men’s Ministry',
        'Building godly men who lead their families and communities in faith.',
        Icons.man,
        'assets/mens_ministry_original.jpg',
      ],
      [
        'Women’s Ministry',
        'Equipping women to grow in faith, prayer, fellowship and service.',
        Icons.woman,
        'assets/women_ministry.jpg',
      ],
      [
        'Youth Ministry',
        'Raising a generation of young people committed to Christ.',
        Icons.groups,
        'assets/youth_ministry.jpg',
      ],
      [
        'Sunday School',
        'Teaching children the Word of God and nurturing them in Christ.',
        Icons.child_care,
        JgarmImageAssets.sundaySchool,
      ],
      [
        'Worship Ministry',
        'Leading the congregation into sincere worship and praise.',
        Icons.music_note,
        JgarmImageAssets.worshipMinistry,
      ],
      [
        'Evangelism Ministry',
        'Taking the Gospel of Jesus Christ to individuals and communities.',
        Icons.public,
        'assets/evangelism_ministry.jpg',
      ],
      [
        'Hospital Ministry',
        'Sharing prayer, encouragement and compassionate care with patients and families.',
        Icons.local_hospital,
        'assets/hospital_ministry.jpg',
      ],
      [
        'Outreach Ministry',
        'Taking the love and hope of Christ into neighbourhoods and communities through practical service and Gospel witness.',
        Icons.volunteer_activism,
        JgarmImageAssets.serveWithUs,
      ],
      [
        'Grace Home Children Centre',
        'Serving vulnerable children and families through love and practical care.',
        Icons.home,
        JgarmImageAssets.supportGhcc,
      ],
    ];

    return SimplePage(
      title: 'Ministries',
      subtitle: 'Serving God and His people',
      icon: Icons.groups,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth >= 900
              ? 3
              : constraints.maxWidth >= 600
                  ? 2
                  : 1;

          return GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: ministries.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: columns,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 0.95,
            ),
            itemBuilder: (context, index) {
              return _featureCard(
                icon: ministries[index][2] as IconData,
                title: ministries[index][0] as String,
                text: ministries[index][1] as String,
                imagePath: ministries[index].length > 3
                    ? ministries[index][3] as String
                    : null,
              );
            },
          );
        },
      ),
    );
  }

  Widget _getInvolvedPage() {
    final items = [
      [
        'Worship With Us',
        'Join us in worship, fellowship, prayer and the teaching of God’s Word.',
        Icons.church,
        JgarmImageAssets.worshipMinistry,
      ],
      [
        'Grow With Us',
        'Grow spiritually through discipleship, Bible teaching and fellowship.',
        Icons.trending_up,
        JgarmImageAssets.growWithUs,
      ],
      [
        'Serve With Us',
        'Use your gifts and abilities to serve God and His people.',
        Icons.volunteer_activism,
        JgarmImageAssets.serveWithUs,
      ],
      [
        'Support GHCC',
        'Help us care for vulnerable children and families through GHCC.',
        Icons.favorite,
        JgarmImageAssets.supportGhcc,
      ],
    ];

    return SimplePage(
      title: 'Get Involved',
      subtitle: 'Join us in the work of the Gospel',
      icon: Icons.handshake,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth >= 900 ? 2 : 1;
          const spacing = 18.0;
          final cardWidth = columns == 1
              ? constraints.maxWidth
              : (constraints.maxWidth - spacing) / 2;
          return Wrap(
            spacing: spacing,
            runSpacing: spacing,
            children: items.map((item) => SizedBox(
              width: cardWidth,
              child: _featureCard(
                icon: item[2] as IconData,
                title: item[0] as String,
                text: item[1] as String,
                imagePath: item.length > 3 ? item[3] as String : null,
              ),
            )).toList(),
          );
        },
      ),
    );
  }

  Widget _servicesPage() {
    return SimplePage(
      title: 'Church Services',
      subtitle: 'Weekly, monthly and annual ministry programme',
      icon: Icons.church,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset(
              'assets/jgarm_church_auditorium.png',
              width: double.infinity,
              height: 210,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 18),
          const ProgrammeTable(),
        ],
      ),
    );
  }

  Widget _sermonsPage() {
    final sermons = [
      {
        'title': 'JGARM Gospel Ministry',
        'description': 'Watch the latest ministry message.',
        'url': 'https://youtu.be/UGhKYGsjjlI',
      },
      {
        'title': 'JGARM Teaching & Worship',
        'description': 'Connect with JGARM through teaching and worship.',
        'url': 'https://youtu.be/m5Ouyi_ij6w',
      },
      {
        'title': 'JGARM Ministry Message',
        'description': 'Be encouraged through the Word of God.',
        'url': 'https://youtu.be/TsWEUTrYCHg',
      },
    ];

    return SimplePage(
      title: 'Sermons',
      subtitle: 'Messages, teachings and ministry',
      icon: Icons.menu_book,
      child: Column(
        children: sermons.map((sermon) {
          return Container(
            margin: const EdgeInsets.only(bottom: 16),
            child: _videoCard(
              title: sermon['title']!,
              description: sermon['description']!,
              url: sermon['url']!,
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _eventsPage() {
    final events = [
      [
        'Sunday Fellowship',
        'Weekly fellowship, worship, teaching and prayer.',
        Icons.church,
        JgarmImageAssets.sundayFellowship,
      ],
      [
        'Prayer Meeting',
        'Corporate prayer and intercession for the church and community.',
        Icons.volunteer_activism,
        JgarmImageAssets.prayerMeeting,
      ],
      [
        'Youth Services',
        'A special time for young people to worship, learn and fellowship.',
        Icons.groups,
        JgarmImageAssets.youthServices,
      ],
      [
        'Monthly Kesha',
        'A monthly overnight programme held during the first weekend of the month.',
        Icons.nightlight_round,
      ],
    ];

    return SimplePage(
      title: 'Events',
      subtitle: 'Upcoming and regular JGARM gatherings',
      icon: Icons.event,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth >= 800 ? 2 : 1;
          const spacing = 18.0;
          final cardWidth = columns == 1
              ? constraints.maxWidth
              : (constraints.maxWidth - spacing) / 2;
          return Wrap(
            spacing: spacing,
            runSpacing: spacing,
            children: events.map((event) => SizedBox(
              width: cardWidth,
              child: _featureCard(
                icon: event[2] as IconData,
                title: event[0] as String,
                text: event[1] as String,
                imagePath: event.length > 3 ? event[3] as String : null,
              ),
            )).toList(),
          );
        },
      ),
    );
  }

  Widget _prayerPage() {
    return SimplePage(
      title: 'Prayer Request',
      subtitle: 'Bring Your Prayer Needs',
      icon: Icons.volunteer_activism,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.asset(
                JgarmImageAssets.prayerRequests,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.volunteer_activism, size: 75, color: JgarmColors.pink),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'We believe in the power of prayer.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          const Text(
            'You can bring your prayer needs to us. We will stand with you in prayer concerning financial challenges, domestic violence and strife, drunkenness, sickness, illness and every other burden.',
            textAlign: TextAlign.center,
            style: TextStyle(
              height: 1.7,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            '“The prayers of the righteous avail much.”',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.pink,
              fontWeight: FontWeight.bold,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 25),
          ElevatedButton.icon(
            onPressed: _emailPrayerRequest,
            icon: const Icon(Icons.email),
            label: const Text('SUBMIT A PRAYER REQUEST'),
            style: ElevatedButton.styleFrom(
              backgroundColor: JgarmColors.pink,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 15,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _emailPrayerRequest() async {
    final uri = Uri(
      scheme: 'mailto',
      path: 'jesus.graceandrestorationministry@gmail.com',
      queryParameters: {
        'subject': 'JGARM Prayer Request',
      },
    );

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Widget _ghccPage() {
    final gallery = [
      'assets/ghcc_children_1.jpg',
      'assets/ghcc_children_2.jpg',
      'assets/ghcc_children_3.jpg',
    ];

    return SimplePage(
      title: 'GHCC',
      subtitle: 'Grace Home Children Centre',
      icon: Icons.child_care,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: JgarmColors.veryLightBlue,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: JgarmColors.lightBlue),
            ),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(13),
                  child: Image.asset(
                    JgarmImageAssets.ghccPhoto,
                    width: double.infinity,
                    height: 220,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 220,
                      color: JgarmColors.veryLightBlue,
                      alignment: Alignment.center,
                      child: const Icon(Icons.child_care, size: 64, color: JgarmColors.darkBlue),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Grace Home Children Centre',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: JgarmColors.darkBlue,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'Grace Home Children Centre — care, support and hope for children and families.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Colors.black54, fontStyle: FontStyle.italic),
          ),
          const SizedBox(height: 12),
          const Text(
            'GHCC is a ministry of JGARM serving orphans, vulnerable children and widows in our community.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              height: 1.6,
            ),
          ),
          const SizedBox(height: 25),
          LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 900
                  ? 3
                  : constraints.maxWidth >= 600
                      ? 2
                      : 1;

              return GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: gallery.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.2,
                ),
                itemBuilder: (context, index) {
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Image.asset(
                      gallery[index],
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) {
                        return Container(
                          color: JgarmColors.veryLightBlue,
                          child: const Icon(
                            Icons.image,
                            size: 60,
                            color: JgarmColors.darkBlue,
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          ),
          const SizedBox(height: 25),
          _aboutSection(
            'Care',
            'Providing practical support and care for vulnerable children and families.',
            Icons.volunteer_activism,
          ),
          _aboutSection(
            'Heart',
            'Serving with compassion, dignity and the love of Jesus Christ.',
            Icons.favorite,
          ),
          _aboutSection(
            'Support GHCC',
            'Your support can help provide food, education, clothing and other essential needs.',
            Icons.favorite_border,
          ),
          const SizedBox(height: 15),
          const Text(
            'Please protect the privacy and dignity of children when sharing their photographs or information.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black54,
              fontSize: 12,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _givePage() {
    return SimplePage(
      title: 'Give',
      subtitle: 'Support the work of JGARM',
      icon: Icons.favorite,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset(
              'assets/giving_basket.jpg',
              width: double.infinity,
              height: 180,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 20),
          _givingCard(
            icon: Icons.phone_android,
            title: 'M-PESA',
            rows: const [
              ['Paybill', '522533'],
              ['Account / Till', '7957551'],
              ['Account Name', 'Robinshon'],
            ],
          ),
          const SizedBox(height: 20),
          _givingCard(
            icon: Icons.paypal,
            title: 'PayPal',
            rows: const [
              ['Email', 'robinshonstanley@gmail.com'],
            ],
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: JgarmColors.softAmber,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: JgarmColors.headerGold, width: 1.2),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'OFFICIAL CONTRIBUTION RECIPIENT',
                  style: TextStyle(
                    color: JgarmColors.darkBlue,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'The official recipient of all contributions made on behalf of Jesus Grace and Restoration Ministry (JGARM) is Bishop Robinshon Onyango Stanley. Please confirm that the recipient details match before completing a transfer. Any changes to the ministry’s official payment arrangements will be communicated through JGARM’s official channels as soon as possible. For your protection, please do not rely on alternative payment instructions received through unofficial sources.',
                  style: TextStyle(color: Colors.black87, height: 1.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'INTERNATIONAL GIVING',
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Choose a provider below to open its official transfer service. Select Kenya as the destination and verify the official recipient details before sending.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black87, height: 1.4),
          ),
          const SizedBox(height: 16),
          _givingProviderButton(
            label: 'WorldRemit',
            subtitle: 'Open official transfer service',
            background: const Color(0xFF23845B),
            foreground: Colors.white,
            url: 'https://www.worldremit.com/en/kenya',
            icon: Icons.public,
          ),
          const SizedBox(height: 12),
          _givingProviderButton(
            label: 'Western Union',
            subtitle: 'Open official send-money service',
            background: const Color(0xFFFFD100),
            foreground: const Color(0xFF1E1E1E),
            url: 'https://www.westernunion.com/ke/en/send-money.html',
            icon: Icons.language,
          ),
          const SizedBox(height: 12),
          _givingProviderButton(
            label: 'MoneyGram',
            subtitle: 'Open official transfer service',
            background: const Color(0xFFE31B36),
            foreground: Colors.white,
            url: 'https://www.moneygram.com/r/ke/en',
            icon: Icons.account_balance,
          ),
          const SizedBox(height: 24),
          const Text(
            'Thank you for supporting the work of the Gospel and the ministry of JGARM.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _givingProviderButton({
    required String label,
    required String subtitle,
    required Color background,
    required Color foreground,
    required String url,
    required IconData icon,
  }) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () async {
          final uri = Uri.parse(url);
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri, webOnlyWindowName: '_blank');
          }
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: background,
          foregroundColor: foreground,
          elevation: 2,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, size: 30),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  Text(subtitle, style: const TextStyle(fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.open_in_new, size: 19),
          ],
        ),
      ),
    );
  }

  Widget _givingCard({
    required IconData icon,
    required String title,
    required List<List<String>> rows,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: JgarmColors.paleBlue,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: JgarmColors.lightBlue,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 50,
            color: JgarmColors.pink,
          ),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          ...rows.map(
            (row) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      row[0],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      row[1],
                      textAlign: TextAlign.right,
                    ),
                  ),
                  IconButton(
                    onPressed: () => _copyText(row[1]),
                    icon: const Icon(
                      Icons.copy,
                      color: JgarmColors.pink,
                    ),
                    tooltip: 'Copy',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _copyText(String text) async {
    await Clipboard.setData(
      ClipboardData(text: text),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Copied to clipboard'),
      ),
    );
  }

  Future<void> _callJgarm() async {
    final uri = Uri(
      scheme: 'tel',
      path: '+254721119143',
    );

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _emailJgarm() async {
    final uri = Uri(
      scheme: 'mailto',
      path: 'jesus.graceandrestorationministry@gmail.com',
      queryParameters: {
        'subject': 'JGARM Contact',
      },
    );

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _emailJgarm2016() async {
    final uri = Uri(
      scheme: 'mailto',
      path: 'jgarm2016@gmail.com',
      queryParameters: {'subject': 'JGARM Contact'},
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _openWhatsApp() async {
    final uri = Uri.parse(
      'https://wa.me/254721119143?text=Hello%20JGARM%2C%20I%20would%20like%20to%20get%20in%20touch.',
    );

    if (await canLaunchUrl(uri)) {
      await launchUrl(
        uri,
        webOnlyWindowName: '_blank',
      );
    }
  }

  Widget _contactPage() {
    return SimplePage(
      title: 'Contact Us',
      subtitle: 'We would love to hear from you',
      icon: Icons.contact_mail,
      child: Column(
        children: [
          const Text(
            'JGARM CHURCH',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'Jesus Grace And Restoration Ministry',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.pink,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 25),
          _contactItem(
            Icons.location_on,
            'Headquarters',
            'Gwassi–Seka, Suba, Kenya',
          ),
          _contactItem(
            Icons.markunread_mailbox,
            'Postal Address',
            'P.O. Box 24-40307',
          ),
          InkWell(
            onTap: _callJgarm,
            child: _contactItem(
              Icons.phone,
              'Phone',
              '+254 721 119 143 / +254 715 205 485',
            ),
          ),
          InkWell(
            onTap: _emailJgarm,
            child: _contactItem(
              Icons.email,
              'Email',
              'jesus.graceandrestorationministry@gmail.com',
            ),
          ),
          InkWell(
            onTap: _emailJgarm2016,
            child: _contactItem(
              Icons.email_outlined,
              'JGARM Email',
              'jgarm2016@gmail.com',
            ),
          ),
          InkWell(
            onTap: _openWhatsApp,
            child: _contactItem(
              Icons.chat,
              'WhatsApp',
              'Chat with JGARM on WhatsApp',
            ),
          ),
        ],
      ),
    );
  }

  Widget _contactItem(
    IconData icon,
    String title,
    String text,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 7),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: JgarmColors.paleBlue,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: JgarmColors.pink,
            size: 30,
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: JgarmColors.darkBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(text),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SimplePage extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget child;

  const SimplePage({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: JgarmColors.veryLightBlue,
        child: Column(
          children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 45,
            ),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [JgarmColors.darkBlue, JgarmColors.royalBlue],
              ),
              border: Border(bottom: BorderSide(color: JgarmColors.amber, width: 5)),
            ),
            child: Column(
              children: [
                Icon(
                  icon,
                  size: 55,
                  color: JgarmColors.amber,
                ),
                const SizedBox(height: 12),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: JgarmColors.amber,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            constraints: const BoxConstraints(maxWidth: 1000),
            padding: const EdgeInsets.all(20),
            child: child,
          ),
          const ContactFooter(),
          ],
        ),
      ),
    );
  }
}

class JgarmLeadershipCarousel extends StatefulWidget {
  final List<Map<String, String>> leaders;
  const JgarmLeadershipCarousel({super.key, required this.leaders});

  @override
  State<JgarmLeadershipCarousel> createState() => _JgarmLeadershipCarouselState();
}

class _JgarmLeadershipCarouselState extends State<JgarmLeadershipCarousel> {
  late final PageController _controller;
  Timer? _timer;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _controller = PageController(viewportFraction: 0.78);
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_controller.hasClients || widget.leaders.isEmpty) return;
      final next = (_page + 1) % widget.leaders.length;
      _controller.animateToPage(next, duration: const Duration(milliseconds: 600), curve: Curves.easeInOut);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 900;
    return Container(
      width: double.infinity,
      color: JgarmColors.paleBlue,
      padding: const EdgeInsets.fromLTRB(8, 18, 8, 16),
      child: Column(
        children: [
          const Text('MEET OUR LEADERSHIP', style: TextStyle(color: JgarmColors.darkBlue, fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
          const SizedBox(height: 4),
          const Text('Serving God, His Church and His people', style: TextStyle(color: JgarmColors.pink, fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          SizedBox(
            height: wide ? 218 : 206,
            child: PageView.builder(
              controller: _controller,
              itemCount: widget.leaders.length,
              onPageChanged: (value) => setState(() => _page = value),
              itemBuilder: (context, index) {
                final leader = widget.leaders[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Card(
                    elevation: 3,
                    margin: EdgeInsets.zero,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: JgarmColors.lightBlue)),
                    clipBehavior: Clip.antiAlias,
                    child: Row(
                      children: [
                        SizedBox(
                          width: wide ? 150 : 112,
                          height: double.infinity,
                          child: Image.asset(leader['photo']!, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(color: JgarmColors.paleBlue, alignment: Alignment.center, child: Container(width: 76, height: 76, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [JgarmColors.darkBlue, Color(0xFF315D7D)])), child: const Icon(Icons.person, size: 48, color: JgarmColors.softAmber)))),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(leader['name']!, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: JgarmColors.darkBlue, fontSize: 14, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 5),
                                Text(leader['position']!, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: JgarmColors.pink, fontSize: 11, fontWeight: FontWeight.w700)),
                                const SizedBox(height: 7),
                                Text(leader['message']!, maxLines: wide ? 3 : 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black87, fontSize: 10, height: 1.35)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(widget.leaders.length, (index) => AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            margin: const EdgeInsets.symmetric(horizontal: 3),
            width: _page == index ? 18 : 6,
            height: 6,
            decoration: BoxDecoration(color: _page == index ? JgarmColors.pink : JgarmColors.lightBlue, borderRadius: BorderRadius.circular(5)),
          ))),
        ],
      ),
    );
  }
}

class JgarmUpdatesCarousel extends StatefulWidget {
  const JgarmUpdatesCarousel({super.key});

  @override
  State<JgarmUpdatesCarousel> createState() => _JgarmUpdatesCarouselState();
}

class _JgarmUpdatesCarouselState extends State<JgarmUpdatesCarousel> {
  final PageController _controller = PageController(viewportFraction: 0.92);
  Timer? _rotationTimer;
  int _currentPage = 0;

  final List<Map<String, dynamic>> _updates = const [
    {
      'imagePath': 'assets/hospital_ministry_with_you.jpg',
      'showCaption': false,
      'eyebrow': 'HOSPITAL MINISTRY',
      'title': 'Hospital Ministry',
      'body': 'Bringing hope and comfort to those who need care.',
    },
    {
      'imagePath': JgarmImageAssets.worshipMinistry,
      'showCaption': false,
      'eyebrow': 'WORSHIP MINISTRY',
      'title': 'Worship Ministry',
      'body': 'His presence. Our sound. One voice.',
    },
    {
      'imagePath': JgarmImageAssets.sundaySchool,
      'showCaption': false,
      'eyebrow': 'SUNDAY SCHOOL',
      'title': 'Sunday School',
      'body': "Growing in God's Word, together.",
    },
    {
      'imagePath': JgarmImageAssets.growWithUs,
      'showCaption': false,
      'eyebrow': 'GROW WITH US',
      'title': 'Grow With Us',
      'body': 'Faith. Family. Purpose.',
    },
    {
      'imagePath': 'assets/prayer_requests.jpg',
      'showCaption': false,
      'eyebrow': 'PRAYER REQUESTS',
      'title': 'Prayer Requests',
      'body': 'You are not alone. We are praying with you.',
    },
    {
      'imagePath': 'assets/mens_ministry.jpg',
      'showCaption': false,
      'eyebrow': "MEN'S MINISTRY",
      'title': "Men's Ministry",
      'body': 'Strong men. Godly fathers. Faithful brothers.',
    },
    {
      'imagePath': JgarmImageAssets.compassionCommunity,
      'showCaption': false,
      'eyebrow': 'COMPASSION & COMMUNITY TRANSFORMATION',
      'title': 'Compassion & Community Transformation',
      'body': 'Loving people. Changing communities.',
    },
    {
      'imagePath': JgarmImageAssets.joinUs,
      'showCaption': false,
      'eyebrow': 'JOIN US',
      'title': 'Join Us',
      'body': 'You belong here. Come as you are.',
    },
    {
      'imagePath': JgarmImageAssets.prayerMeeting,
      'showCaption': false,
      'eyebrow': 'PRAYER',
      'title': 'Prayer',
      'body': 'Seek Him. Hear Him. Trust Him.',
    },
    {
      'eyebrow': 'CHURCH ANNOUNCEMENTS',
      'title': 'Stay connected with the JGARM family',
      'body': 'Find ministry news, important notices and updates from our church community.',
      'icon': Icons.notifications_active_rounded,
      'color': Color(0xFF315D7D),
    },
    {
      'eyebrow': 'SERVICES & FELLOWSHIP',
      'title': 'Grow together in faith',
      'body': 'Join us for worship, biblical teaching, prayer, fellowship and ministry gatherings.',
      'icon': Icons.church,
      'color': Color(0xFFA84770),
    },
    {
      'eyebrow': 'EVENTS & MINISTRIES',
      'title': 'Worship. Grow. Serve. Together.',
      'body': 'Discover opportunities to participate, serve and build up the body of Christ.',
      'icon': Icons.event,
      'color': Color(0xFF477895),
    },
    {
      'eyebrow': 'GRACE HOME CHILDREN CENTRE',
      'title': 'Sharing grace, hope and restoration',
      'body': 'Stand with vulnerable children and families through practical care and Christian love.',
      'icon': Icons.volunteer_activism,
      'color': Color(0xFF9B527A),
    },
    {
      'imagePath': 'assets/jgarm_flapping_dove.webp',
      'eyebrow': 'THE FIRE OF THE GOSPEL ABLAZE',
      'title': 'A ministry carried by the Spirit',
      'body': 'The JGARM flapping dove.',
    },
    {
      'imagePath': 'assets/giphy.gif',
      'eyebrow': 'CHRIST AT THE CENTRE',
      'title': 'Jesus Christ, the heart of our faith',
      'body': 'Our worship, teaching and service remain centred on Jesus Christ.',
    },
    {
      'imagePath': 'assets/jgarm_church_auditorium.png',
      'eyebrow': 'OUR CHURCH FAMILY',
      'title': 'A place to worship and grow',
      'body': 'The JGARM church hall and worship space.',
    },
    {
      'imagePath': 'assets/prayer_ministry.jpg',
      'eyebrow': 'PRAYER MINISTRY',
      'title': 'Standing together in prayer',
      'body': 'We welcome your prayer needs and stand with you in faith.',
    },
    {
      'imagePath': 'assets/outreach_ministry.jpg',
      'eyebrow': 'OUTREACH MINISTRY',
      'title': 'Taking the Gospel beyond our walls',
      'body': 'Serving communities and sharing the hope of Jesus Christ.',
    },
    {
      'imagePath': 'assets/the_ministry.png',
      'eyebrow': 'THE MINISTRY',
      'title': 'Jesus Grace and Restoration Ministry',
      'body': 'The ministry’s calling to proclaim the Gospel and make disciples.',
    },
  ];

  @override
  void initState() {
    super.initState();
    _rotationTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_controller.hasClients) return;
      final nextPage = (_currentPage + 1) % _updates.length;
      _controller.animateToPage(
        nextPage,
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _rotationTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _goToPage(int offset) {
    if (!_controller.hasClients) return;
    final nextPage = (_currentPage + offset + _updates.length) % _updates.length;
    _controller.animateToPage(
      nextPage,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: JgarmColors.paleBlue,
      padding: const EdgeInsets.only(top: 18, bottom: 16),
      child: Column(
        children: [
          const Text(
            'WHAT’S HAPPENING AT JGARM',
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 194,
            child: Stack(
              children: [
                PageView.builder(
                  controller: _controller,
                  itemCount: _updates.length,
                  onPageChanged: (index) => setState(() => _currentPage = index),
                  itemBuilder: (context, index) {
                    final update = _updates[index];
                    final imagePath = update['imagePath'] as String?;
                    if (imagePath != null) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              Image.asset(
                                imagePath,
                                fit: BoxFit.cover,
                                gaplessPlayback: true,
                                errorBuilder: (_, __, ___) => Container(
                                  color: JgarmColors.darkBlue,
                                  child: const Icon(Icons.image_not_supported,
                                      color: Colors.white, size: 42),
                                ),
                              ),
                              if (update['showCaption'] != false)
                                DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        Colors.black.withOpacity(0.78),
                                      ],
                                    ),
                                  ),
                                ),
                              if (update['showCaption'] != false)
                                Positioned(
                                  left: 20,
                                  right: 20,
                                  bottom: 16,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        update['eyebrow'] as String,
                                        style: const TextStyle(
                                          color: JgarmColors.lightBlue,
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1,
                                        ),
                                      ),
                                      const SizedBox(height: 5),
                                      Text(
                                        update['title'] as String,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        update['body'] as String,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }

                    final color = update['color'] as Color;
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [color, color.withOpacity(0.82)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x18000000),
                              blurRadius: 10,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 76,
                              height: 76,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.14),
                                border: Border.all(
                                  color: JgarmColors.softAmber,
                                  width: 2,
                                ),
                              ),
                              child: Icon(
                                update['icon'] as IconData,
                                color: Colors.white,
                                size: 43,
                              ),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    update['eyebrow'] as String,
                                    style: const TextStyle(
                                      color: JgarmColors.lightBlue,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                  const SizedBox(height: 7),
                                  Text(
                                    update['title'] as String,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 19,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    update['body'] as String,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      height: 1.35,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                Positioned(
                  left: 2,
                  top: 70,
                  child: _carouselArrow(Icons.chevron_left, () => _goToPage(-1)),
                ),
                Positioned(
                  right: 2,
                  top: 70,
                  child: _carouselArrow(Icons.chevron_right, () => _goToPage(1)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _updates.length,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 2),
                width: _currentPage == index ? 18 : 5,
                height: 6,
                decoration: BoxDecoration(
                  color: _currentPage == index
                      ? JgarmColors.pink
                      : JgarmColors.lightBlue,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _carouselArrow(IconData icon, VoidCallback onPressed) {
    return Material(
      color: Colors.white.withOpacity(0.82),
      shape: const CircleBorder(),
      child: IconButton(
        tooltip: icon == Icons.chevron_left ? 'Previous slide' : 'Next slide',
        onPressed: onPressed,
        icon: Icon(icon, color: JgarmColors.darkBlue, size: 25),
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}

class ProgrammePreview extends StatelessWidget {
  const ProgrammePreview({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> programme = [
      {
        'day': 'Sunday',
        'title': 'Main Worship Service',
        'time': '8:00 AM - 4:00 PM',
        'icon': 'church',
        'details':
            'Our main Sunday gathering with prayer, worship, teachings, testimonies, the sermon, fellowship and other church activities.',
        'activities': [
          'Prayer & Intercession - 8:00 AM - 9:00 AM',
          'Worship - 9:00 AM - 9:15 AM',
          'Teachings - 9:15 AM - 10:15 AM',
          'Reports - 10:15 AM - 10:25 AM',
          'Sunday School Presentations - 10:25 AM - 10:35 AM',
          'Praise & Worship - 10:35 AM - 10:45 AM',
          'Testimonies - 10:45 AM - 10:55 AM',
          'Praise & Worship - 10:55 AM - 11:20 AM',
          'Sermon - 11:20 AM - 12:20 PM',
          'Lunch - 12:20 PM - 2:00 PM',
          'Sisters\' Sessions - 2:00 PM - 4:00 PM',
        ],
      },
      {
        'day': 'Tuesday',
        'title': 'Sisters / Women\'s Ministry',
        'time': '2:00 PM - 4:00 PM',
        'icon': 'women',
        'details':
            'A special time of fellowship, prayer, teaching and spiritual encouragement for women.',
        'activities': [
          'Women\'s / Sisters\' Ministry - 2:00 PM - 4:00 PM',
          'Fellowship',
          'Prayer',
          'Biblical Teaching',
          'Spiritual Encouragement',
        ],
      },
      {
        'day': 'Thursday',
        'title': 'Men\'s Teaching',
        'time': '3:00 PM - 5:00 PM',
        'icon': 'men',
        'details':
            'Men gather for Biblical teaching, prayer, fellowship and spiritual growth.',
        'activities': [
          'Men\'s Teaching - 3:00 PM - 5:00 PM',
          'Biblical Teaching',
          'Prayer',
          'Fellowship',
          'Spiritual Growth',
        ],
      },
      {
        'day': 'Friday',
        'title': 'Prayer Meeting',
        'time': '5:00 PM - 7:00 PM',
        'icon': 'prayer',
        'details':
            'Join us for corporate prayer, intercession and seeking God together.',
        'activities': [
          'Prayer Meeting - 5:00 PM - 7:00 PM',
          'Corporate Prayer',
          'Intercession',
          'Seeking God Together',
        ],
      },
      {
        'day': 'Saturday',
        'title': 'Youth Service',
        'time': '2:00 PM - 5:00 PM',
        'icon': 'youth',
        'details':
            'A gathering for young people featuring worship, Biblical teaching, prayer and fellowship.',
        'activities': [
          'Youth Service - 2:00 PM - 5:00 PM',
          'Worship',
          'Biblical Teaching',
          'Prayer',
          'Fellowship',
        ],
      },
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      color: JgarmColors.paleBlue,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Text(
            'Weekly Programme',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Tap any programme to view the full programme',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.pink,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 20),
          ...programme.map((item) {
            IconData icon;

            switch (item['icon']) {
              case 'church':
                icon = Icons.church;
                break;
              case 'women':
                icon = Icons.woman;
                break;
              case 'men':
                icon = Icons.man;
                break;
              case 'prayer':
                icon = Icons.volunteer_activism;
                break;
              default:
                icon = Icons.groups;
            }

            final List<String> activities =
                List<String>.from(item['activities']);

            return Card(
              elevation: 3,
              margin: const EdgeInsets.only(bottom: 14),
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: const BorderSide(
                  color: JgarmColors.lightBlue,
                ),
              ),
              child: ExpansionTile(
                leading: Icon(
                  icon,
                  color: JgarmColors.pink,
                  size: 30,
                ),
                title: Text(
                  item['title'],
                  style: const TextStyle(
                    color: JgarmColors.darkBlue,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Text(
                    '${item['day']}  •  ${item['time']}',
                    style: const TextStyle(
                      color: JgarmColors.pink,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ),
                iconColor: JgarmColors.darkBlue,
                collapsedIconColor: JgarmColors.pink,
                childrenPadding: const EdgeInsets.fromLTRB(
                  20,
                  0,
                  20,
                  18,
                ),
                children: [
                  const Divider(
                    color: JgarmColors.lightBlue,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    item['details'],
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.black87,
                      fontSize: 14,
                      height: 1.6,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Programme Details',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: JgarmColors.darkBlue,
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  ...activities.map(
                    (activity) => Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 11,
                      ),
                      decoration: BoxDecoration(
                        color: JgarmColors.paleBlue,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: JgarmColors.lightBlue,
                        ),
                      ),
                      child: Text(
                        activity,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: JgarmColors.darkBlue,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
               

class ProgrammeTable extends StatelessWidget {
  const ProgrammeTable({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _sectionHeader(
          'Weekly Programme',
          'Tap any programme to view details',
          Icons.calendar_view_week,
        ),

        _programmeCard(
          context,
          'Sunday Main Worship Service',
          'Sunday',
          '8:00 AM – 4:00 PM',
          Icons.church,
        ),

        _programmeCard(
          context,
          'Tuesday Sisters’ / Women’s Ministry',
          'Tuesday',
          '2:00 PM – 4:00 PM',
          Icons.woman,
        ),

        _programmeCard(
          context,
          'Wednesday Hospital Ministry',
          'Wednesday',
          'Scheduled Hospital Visits',
          Icons.local_hospital,
          reference: 'Matthew 25:35–36',
        ),

        _programmeCard(
          context,
          'Thursday Men’s Teaching',
          'Thursday',
          '3:00 PM – 5:00 PM',
          Icons.man,
        ),

        _programmeCard(
          context,
          'Friday Prayer Meeting',
          'Friday',
          '5:00 PM – 7:00 PM',
          Icons.volunteer_activism,
        ),

        _programmeCard(
          context,
          'Saturday Youth Service',
          'Saturday',
          '2:00 PM – 5:00 PM',
          Icons.groups,
        ),

        const SizedBox(height: 30),

        _sectionHeader(
          'Detailed Sunday Programme',
          'Main Sunday worship schedule',
          Icons.schedule,
        ),

        _sundayProgrammeCard(),

        const SizedBox(height: 30),

        _sectionHeader(
          'Monthly Programme',
          'Monthly Kesha — First Weekend of Every Month',
          Icons.nightlight_round,
        ),

        _monthlyKeshaCard(),

        const SizedBox(height: 30),

        _sectionHeader(
          'Annual Programme',
          'Major annual JGARM programmes',
          Icons.event_available,
        ),

        _annualProgramme(),
      ],
    );
  }

  static Widget _sectionHeader(
    String title,
    String subtitle,
    IconData icon,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            JgarmColors.veryLightBlue,
            Colors.white,
          ],
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 45,
            color: JgarmColors.pink,
          ),
          const SizedBox(height: 10),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: JgarmColors.pink,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  static Widget _programmeCard(
    BuildContext context,
    String title,
    String day,
    String time,
    IconData icon, {
    String? reference,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: JgarmColors.lightBlue,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: () {
            _showProgrammeDetails(
              context,
              title,
              day,
              time,
              icon,
              reference,
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: JgarmColors.veryLightBlue,
                  child: Icon(
                    icon,
                    color: JgarmColors.darkBlue,
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: JgarmColors.darkBlue,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text('$day • $time'),
                      if (reference != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          reference,
                          style: const TextStyle(
                            color: JgarmColors.pink,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(
                  Icons.chevron_right,
                  color: JgarmColors.pink,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static void _showProgrammeDetails(
    BuildContext context,
    String title,
    String day,
    String time,
    IconData icon,
    String? reference,
  ) {
    if (title == 'Sunday Main Worship Service') {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Row(
              children: [
                const Icon(
                  Icons.church,
                  color: JgarmColors.pink,
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Sunday Main Worship Service',
                    style: TextStyle(
                      color: JgarmColors.darkBlue,
                      fontSize: 18,
                    ),
                  ),
                ),
              ],
            ),
            content: SizedBox(
              width: 500,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _detailRow(
                      '1',
                      'Prayer & Intercession',
                      '8:00 AM – 9:00 AM',
                    ),
                    _detailRow(
                      '2',
                      'Worship',
                      '9:00 AM – 9:15 AM',
                    ),
                    _detailRow(
                      '3',
                      'Teachings',
                      '9:15 AM – 10:15 AM',
                    ),
                    _detailRow(
                      '4',
                      'Reports',
                      '10:15 AM – 10:25 AM',
                    ),
                    _detailRow(
                      '5',
                      'Sunday School Presentations',
                      '10:25 AM – 10:35 AM',
                    ),
                    _detailRow(
                      '6',
                      'Praise & Worship',
                      '10:35 AM – 10:45 AM',
                    ),
                    _detailRow(
                      '7',
                      'Testimonies',
                      '10:45 AM – 10:55 AM',
                    ),
                    _detailRow(
                      '8',
                      'Praise & Worship',
                      '10:55 AM – 11:20 AM',
                    ),
                    _detailRow(
                      '9',
                      'Sermon',
                      '11:20 AM – 12:20 PM',
                    ),
                    _detailRow(
                      '10',
                      'Lunch',
                      '12:20 PM – 2:00 PM',
                    ),
                    _detailRow(
                      '11',
                      'Sisters’ Sessions',
                      '2:00 PM – 4:00 PM',
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  'CLOSE',
                  style: TextStyle(
                    color: JgarmColors.pink,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          );
        },
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Row(
            children: [
              CircleAvatar(
                backgroundColor: JgarmColors.veryLightBlue,
                child: Icon(
                  icon,
                  color: JgarmColors.darkBlue,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: JgarmColors.darkBlue,
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                day,
                style: const TextStyle(
                  color: JgarmColors.pink,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                time,
                style: const TextStyle(
                  color: JgarmColors.darkBlue,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (reference != null) ...[
                const SizedBox(height: 12),
                Text(
                  reference,
                  style: const TextStyle(
                    color: JgarmColors.pink,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'CLOSE',
                style: TextStyle(
                  color: JgarmColors.pink,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  static Widget _detailRow(
    String number,
    String programme,
    String time,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: JgarmColors.paleBlue,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 15,
            backgroundColor: JgarmColors.pink,
            child: Text(
              number,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              programme,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            time,
            textAlign: TextAlign.right,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  static Widget _sundayProgrammeCard() {
    final items = [
      ['1', 'Prayer & Intercession', '8:00 AM – 9:00 AM'],
      ['2', 'Worship', '9:00 AM – 9:15 AM'],
      ['3', 'Teachings', '9:15 AM – 10:15 AM'],
      ['4', 'Reports', '10:15 AM – 10:25 AM'],
      [
        '5',
        'Sunday School Presentations',
        '10:25 AM – 10:35 AM',
      ],
      ['6', 'Praise & Worship', '10:35 AM – 10:45 AM'],
      ['7', 'Testimonies', '10:45 AM – 10:55 AM'],
      ['8', 'Praise & Worship', '10:55 AM – 11:20 AM'],
      ['9', 'Sermon', '11:20 AM – 12:20 PM'],
      ['10', 'Lunch', '12:20 PM – 2:00 PM'],
      ['11', 'Sisters’ Sessions', '2:00 PM – 4:00 PM'],
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: JgarmColors.paleBlue,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: items.map((item) {
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 15,
                  backgroundColor: JgarmColors.pink,
                  child: Text(
                    item[0],
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item[1],
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  item[2],
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: JgarmColors.darkBlue,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  static Widget _monthlyKeshaCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: JgarmColors.paleBlue,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: JgarmColors.lightBlue,
        ),
      ),
      child: Column(
        children: [
          _keshaItem(
            'Friday',
            'Revival',
            '8:00 PM – 10:00 PM',
          ),
          _keshaItem(
            'Saturday',
            'Morning Devotion',
            '4:00 AM – 6:00 AM',
          ),
          _keshaItem(
            'Saturday',
            'Afternoon Teaching',
            '3:00 PM – 4:30 PM',
          ),
          _keshaItem(
            'Saturday',
            'Revival',
            '8:00 PM – 10:00 PM',
          ),
          _keshaItem(
            'Sunday',
            'Morning Devotion',
            '4:00 AM – 6:00 AM',
          ),
          _keshaItem(
            'Sunday',
            'Main Worship Service',
            '8:00 AM – 2:00 PM',
          ),
        ],
      ),
    );
  }

  static Widget _keshaItem(
    String day,
    String programme,
    String time,
  ) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            day,
            style: const TextStyle(
              color: JgarmColors.pink,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            programme,
            style: const TextStyle(
              color: JgarmColors.darkBlue,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 3),
          Text(time),
        ],
      ),
    );
  }

  static Widget _annualProgramme() {
    final items = [
      ['April', 'Women’s Convention'],
      ['June', 'General Leadership Seminar'],
      ['August', 'Youth Convention'],
      ['October', 'General Pastors’ Meeting'],
      ['December', 'Annual General Convention'],
      ['December', 'Annual General Meeting (AGM) — Board'],
    ];

    return Column(
      children: items.map((item) {
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: JgarmColors.lightBlue,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 13,
                  vertical: 9,
                ),
                decoration: BoxDecoration(
                  color: JgarmColors.darkBlue,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  item[0],
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Text(
                  item[1],
                  style: const TextStyle(
                    color: JgarmColors.darkBlue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }
}
 
          
       

class ContactFooter extends StatelessWidget {
  const ContactFooter({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 25,
        vertical: 35,
      ),
      color: JgarmColors.darkBlue,
      child: Column(
        children: [
          Image.asset(
            'assets/jgarmchurch_logo.jpg',
            height: 100,
            width: 100,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) {
              return const Icon(
                Icons.church,
                color: Colors.white,
                size: 70,
              );
            },
          ),
          const SizedBox(height: 15),
          const Text(
            'JESUS GRACE AND RESTORATION MINISTRY',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 7),
          const Text(
            'The Fire of the Gospel Ablaze',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.lightBlue,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Gwassi–Seka, Suba, Kenya',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'P.O. Box 24-40307',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            '+254 721 119 143 / +254 715 205 485',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'www.jgarm.org',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: JgarmColors.lightBlue,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'jesus.graceandrestorationministry@gmail.com',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 25),
          const Divider(
            color: JgarmColors.lightBlue,
          ),
          const SizedBox(height: 15),
          const Text(
            '© JGARM CHURCH. All rights reserved.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}