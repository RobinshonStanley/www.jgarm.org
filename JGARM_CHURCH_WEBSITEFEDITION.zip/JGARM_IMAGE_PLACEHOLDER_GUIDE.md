# JGARM Website – Image and Placeholder Replacement Guide

## Are the placeholders editable?
Yes. The website uses Flutter asset images and standard Material icons. The icons are temporary visual placeholders, not flattened stickers. They can be recoloured, resized, or replaced with real photographs in `lib/main.dart`.

## Replacing existing photographs
To replace a photograph without changing the code, use a new image with the same filename and overwrite the matching file in `assets/`:

- `bishop_portrait.jpg` – Bishop's profile portrait
- `bishop_preaching.jpg` – preaching/ministry photograph
- `chairman_photo.jpg` – chairman/leadership profile
- `asschair_photo.jpg` – assistant chairperson profile
- `treasurer_photo.jpg` – treasurer profile
- `secretary_photo.jpg` – secretary profile
- `coordinator_photo.jpg` – coordinator profile
- `womenleader_photo.jpg` – women's ministry leader
- `instrumentleader_photo.jpg` – worship/instrument ministry leader
- `ghcc_children_1.jpg`, `ghcc_children_2.jpg`, `ghcc_children_3.jpg` – Grace Home Children Centre photographs
- `jgarmchurch_logo.jpg` – official JGARM logo
- `jgarm_official_cover_banner.jpg` – official permanent cover banner

Keep the same filenames and preferably the same image format. Use clear, high-resolution, landscape photos for cards and portrait photos for leaders. Obtain permission before publishing identifiable people's photographs, especially children's photographs.

## Replacing icon placeholders with photographs later
The icon placeholders are native Flutter `Icon` widgets with JGARM navy/blue and amber styling. They are easy to replace in `lib/main.dart` with `Image.asset('assets/your_photo.jpg', fit: BoxFit.cover)` when an approved ministry photograph is available. The vision pillars intentionally use matching coloured icons for now so the page remains polished and consistent.

## Recommended image practice
Use authentic JGARM/church photographs wherever possible. Until supplied, use the coordinated navy-and-amber icon medallions already in the design rather than random smileys, cartoon stickers, or unrelated stock portraits. Do not present stock photographs as actual JGARM members or leaders.

## Branded temporary icon artwork
The temporary church/logo fallback is now a navy-and-royal-blue circular church emblem with a gold rim and cross detail. Announcement and ministry carousel icons use matching outlined medallions. These are native Flutter vector icons, not flattened smiley stickers, and can be changed in `lib/main.dart`. Replace them with approved JGARM photographs or custom artwork when ready.

## Approved animated dove sticker
- `assets/jgarm_flapping_dove.webp` is the user-supplied animated white dove carrying a red rose.
- The 50-frame animated WebP is used as a small decorative element beside the “THE FOUR PILLARS OF OUR VISION” heading.
- Its display size is constrained and uses `BoxFit.contain`; the heading uses a wrapping layout so the element can move below the text on narrow screens without forcing horizontal overflow.
- Keep the original animation file intact when updating the website.

## Added collage crops and supplied church image (20 November 2026)
- `assets/jgarm_church_auditorium.png` — user-supplied branded church auditorium photo used on Home and Church Services.
- `assets/women_ministry.jpg` — cropped Women Ministry conference panel from the approved collage.
- `assets/youth_ministry.jpg` — cropped Youth Ministry worship panel from the approved collage.
- `assets/giving_basket.jpg` — cropped giving basket panel, selected to avoid the incorrect AI logo on the collage cards.
- `assets/ghcc_care_concept.jpg` — illustrative GHCC care image cropped below the collage signage; it must not be described as actual GHCC children.
- `development_references/leadership_meeting_reference.jpg` is a reference only. It contains generated people and must not be presented as actual JGARM leaders. The final group composition must use genuine leadership photographs from the existing assets.


## New ministry and mission photo slots (20 November 2026)
The following six editable image paths are registered in `pubspec.yaml` and used by the corresponding website sections. Replace a file in `assets/` while keeping its exact filename and format; no Dart code changes should be needed.

- `assets/mens_ministry.jpg` — Men’s Ministry card and service preview
- `assets/hospital_ministry.jpg` — Hospital Ministry card and service preview
- `assets/evangelism_ministry.jpg` — Evangelism Ministry card
- `assets/our_mission.jpg` — Our Mission feature on the Vision/Mission section
- `assets/prayer_ministry.jpg` — Prayer feature and Prayer Request page
- `assets/outreach_ministry.jpg` — Outreach Ministry card

Use clear, high-resolution landscape photographs. The website displays ministry cards responsively; use a subject-centred composition so important people/action remain visible when cropped to card proportions. Obtain consent before publishing identifiable people, and appropriate permissions for patients or vulnerable people.

## Additional image paths added

Replace these temporary JGARM-branded JPG panels with your approved photographs, keeping the exact filenames:

- `assets/fellowship.jpg` — Fellowship
- `assets/the_ministry.png` — The Ministry; also included in the homepage image carousel
- `assets/gospel_outreach.jpg` — Gospel Outreach vision pillar
- `assets/giphy.gif` — Jesus / Christ at the Centre vision pillar and homepage image carousel
- `assets/discipleship_equipping.jpg` — Discipleship and Equipping vision pillar
- `assets/jgarm_flapping_dove.webp` — animated dove; used in the Vision section and homepage image carousel
- `assets/jgarm_church_auditorium.png` — JGARM church hall; also included in the homepage image carousel
- `assets/prayer_ministry.jpg` — Prayer image; also included in the homepage image carousel
- `assets/outreach_ministry.jpg` — Outreach image; also included in the homepage image carousel

These paths are registered in `pubspec.yaml` and connected to their corresponding home, About, Vision, or slideshow sections. The Jesus GIF replaces the former missing `christ_at_the_centre.jpg` reference, and the Ministry image uses the supplied PNG filename. Use photographs you have permission to publish.
