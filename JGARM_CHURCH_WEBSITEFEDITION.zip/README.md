# JGARM Church Website

Official website project for **JGARM — Jesus Grace and Restoration Ministry**.

- Official domain: https://www.jgarm.org
- Motto: The Fire of the Gospel Ablaze
- Location: Gwassi–Seka, Suba, Kenya
- Framework: Flutter Web
- Intended online IDE: FlutLab

## Project contents

- `lib/main.dart` — responsive website interface and page navigation.
- `assets/jgarm_official_cover_banner.jpg` — official permanent ministry cover banner used at the top of the homepage.
- `web/jgarm_official_cover_banner.jpg` — public copy for search/social previews.
- `web/index.html` — browser title, metadata, canonical URL, social metadata and structured data.
- `web/manifest.json` — JGARM web-app manifest and ministry icons.
- `web/robots.txt` and `web/sitemap.xml` — search crawler instructions and sitemap.

The permanent official banner is independent of the rotating homepage updates carousel. The carousel rotates through church announcements, services, events/ministries and Grace Home Children Centre information approximately every five seconds.

## Open and run in FlutLab

1. Import this complete ZIP project into FlutLab.
2. Allow dependencies to resolve from `pubspec.yaml`.
3. Run the web emulator and check the homepage, navigation, page back controls, images, giving information and contact links.
4. Build the web project only after the emulator checks pass.
5. Preserve this ZIP as the rollback copy before publishing a replacement to the live website.

## Google Search Console

The site includes a canonical domain, a JGARM primary site name with the full ministry name as its alternate name, Church and WebSite structured data, `robots.txt`, and `sitemap.xml`.

Domain ownership verification in Google Search Console still requires the verification method/token issued to the website owner. After verification, submit:

`https://www.jgarm.org/sitemap.xml`

Do not insert a guessed verification token.


## Permanent site-wide JGARM branding update

The shared site shell now displays the deep navy JGARM header (`#1E3A5F`) with white logo/title/icons and a 4-pixel gold accent line (`#C9A227`). The horizontal navigation remains directly below the header. The official static JGARM cover banner is now displayed beneath the navigation on every page, not only on the homepage. The header, navigation, and banner remain visible while the selected page content scrolls.


New replaceable image slots are documented in `JGARM_IMAGE_PLACEHOLDER_GUIDE.md`: mens_ministry.jpg, hospital_ministry.jpg, evangelism_ministry.jpg, our_mission.jpg, prayer_ministry.jpg, and outreach_ministry.jpg. Replace these files in `assets/` with approved photos using the same filenames.
