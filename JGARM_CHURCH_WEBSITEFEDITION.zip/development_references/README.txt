JGARM image-development references

- original_collage_source.png is the source collage from which the ministry crops were extracted.
- leadership_meeting_reference.jpg is only a composition reference. The people shown are generated and are NOT the actual JGARM leadership team. Do not publish it as a photograph of JGARM leaders.
- Final leadership group composition remains to be completed using the genuine leader photographs already in assets/.
