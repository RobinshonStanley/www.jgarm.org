# JGARM Website — Update Notes

## Included in this delivery

1. Preserved the supplied Flutter website project and its existing ministry pages, photos, giving information and contact actions.
2. Added the official 1000396981 ministry banner as a permanent homepage cover image. It is not part of, and is never replaced by, the rotating updates carousel.
3. Added a separate homepage carousel rotating approximately every five seconds through announcements, services/fellowship, events/ministries and Grace Home Children Centre.
4. Corrected the joined About/Leadership menu labels and aligned all navigation indexes, including quick-access buttons.
5. Added a dedicated Leadership page and visible Back to Home control on inner pages, while retaining access to the navigation drawer.
6. Replaced the default browser title and Flutter placeholder description with official JGARM branding.
7. Updated the official location, telephone numbers, email and website details in the website UI.
8. Added the official JGARM logo to browser/PWA icon sizes and corrected the web manifest.
9. Added canonical URL, search/social metadata, WebSite and Church structured data, robots.txt and sitemap.xml for https://www.jgarm.org.

## Validation performed

- Original source ZIP integrity verified before editing.
- Updated source structure and required asset references checked.
- Dart delimiter scan passed.
- Web manifest JSON validated.
- Both JSON-LD structured data blocks validated as JSON.
- Sitemap XML validated.
- ZIP integrity verified after packaging.

## Important final test

A Flutter SDK was not available in the packaging environment, so a Flutter compile/build and browser emulator test could not be run here. Import the ZIP into FlutLab, resolve dependencies, run the web emulator, and check the pages/navigation/images before publishing. Keep the previous live ZIP as the rollback backup.

Google Search Console ownership verification must be completed by the site owner using the verification token/method issued by Google. After verification, submit `https://www.jgarm.org/sitemap.xml`.


## Site-wide permanent header and banner update
- Changed the shared AppBar to deep navy `#1E3A5F` with white branding, logo fallback and navigation controls.
- Added a thin 4px gold `#C9A227` accent line beneath the header.
- Kept the horizontal navigation directly beneath the header.
- Moved the official static cover banner from the homepage content into the shared page shell, so it appears on every page.
- The header, navigation and banner stay in place while each page's content scrolls.
- Flutter compilation must be confirmed in FlutLab; no Flutter SDK is available in this build environment.

## Vision and image-placeholder refinement
- Harmonised the expanded JGARM vision statement around Christ-centred ministry, Gospel outreach, discipleship/equipping, and compassion/community transformation.
- Added the short vision headline: “Christ at the Centre. Disciples for the Nations. Love in Action.”
- Presented the four vision pillars in responsive navy-and-amber icon cards and retained the established mission statement separately.
- Updated About-section icon treatments and leadership missing-photo fallbacks to coordinated navy/amber medallions instead of plain generic symbols.
- Added `JGARM_IMAGE_PLACEHOLDER_GUIDE.md`, documenting which existing asset filenames can be overwritten with approved real photographs and how icon placeholders can later be replaced.
- The icon placeholders are editable Flutter widgets; they are not baked-in stickers. Real photographs can be supplied later and placed into the documented asset slots.

## Additional update – giving methods and headquarters
- Added WorldRemit, Western Union and MoneyGram buttons to the Give page. Each opens the provider's official Kenya/international transfer page; JGARM recipient details must be confirmed separately before a donor completes a transfer.
- Updated headquarters location to Gwassi–Seka, Suba, Kenya.
- Updated postal address to P.O. Box 24-40307.
- Improved temporary church emblem and carousel icon presentation with JGARM navy/blue and gold medallions.

## Animated dove and vision responsiveness update — 20 November 2026
- Added the exact user-supplied animated dove-and-red-rose WebP as `assets/jgarm_flapping_dove.webp` (50 frames; animation preserved).
- Positioned the dove as a compact decorative element alongside the “THE FOUR PILLARS OF OUR VISION” heading.
- Used a wrapping heading layout and a constrained 82×82 image with `BoxFit.contain`, allowing the text and dove to wrap naturally on narrow screens.
- Registered the new asset in `pubspec.yaml`; all 15 declared website assets were checked and found present.
- Preserved the permanent cover banner without modification. The `assets/` and `web/` banner copies remain byte-for-byte identical to the supplied official banner asset.
- Preserved existing website pages, leadership content, navigation, metadata, giving/contact actions, and existing photographs.

### Validation for this update
- Source ZIP integrity checked before editing; no corrupt entries found.
- Uploaded dove inspected: animated WebP, 341×341 pixels, 50 frames.
- All declared asset paths checked; none missing.
- Web manifest JSON and sitemap XML parsed successfully.
- Permanent cover banner hashes compared; both website copies are unchanged and match the supplied banner.
- Final ZIP integrity and source-file inspection performed after packaging.
- Flutter/Dart SDK is not installed in this packaging environment. Therefore a Flutter compile, FlutLab import, and browser/emulator visual test cannot be truthfully marked as completed here. Import this ZIP into FlutLab and run the web emulator for the final runtime check before publishing to https://www.jgarm.org.


## Collage crop and supplied-photo integration — 20 November 2026
- Added the user-supplied JGARM church auditorium photograph to the Home Church highlight and Church Services page. The supplied image's JGARM identity artwork is retained; no AI-recreated logo was substituted.
- Cropped separate Women Ministry, Youth Ministry, Giving Basket and GHCC illustrative images from the approved collage source. Crops were selected to avoid the incorrect AI logo marks wherever possible.
- Added the Women Ministry and Youth Ministry photographs to their ministry cards, the basket crop to the Give page, and the illustrative GHCC crop to the GHCC gallery.
- The GHCC collage image is explicitly described as illustrative and not as an actual GHCC child photograph.
- Cropped the leadership-meeting panel as a visual reference only. It is not used to depict actual JGARM leaders; the final leadership group composition must use the existing genuine leadership portraits.
- The supplied animated dove remains unchanged in `assets/jgarm_flapping_dove.webp`.
- These source edits have not been compiled with Flutter in this environment. FlutLab testing remains required before publication.


## 20 November 2026 – Ministry image placement and responsive fit correction
- Reused the existing collage-derived assets (no new image generation): women_ministry.jpg, youth_ministry.jpg, giving_basket.jpg and ghcc_care_concept.jpg.
- Added women/youth/church photos to the matching homepage service preview cards and ensured the Women, Youth and GHCC cards on the Ministries page use their matching images.
- Replaced the GHCC icon-only introduction panel with the GHCC illustrative care image; the explicit illustrative-image notice remains.
- Removed the duplicate GHCC care image from the gallery so the intro image is not repeated immediately below.
- Adjusted photo-card vertical proportions and image frame height for better fit across screen widths.
- Replaced the two incorrect auditorium logo emblems with the exact circular emblem cropped from this ZIP's own assets/jgarmchurch_logo.jpg. Other auditorium décor and text remain unchanged.
- Updated ZIP/source checks are not a substitute for Flutter compilation or FlutLab visual testing.


Additional photo placeholders added in this update: Fellowship, The Ministry, Gospel Outreach, Christ at the Centre, and Discipleship and Equipping. Each has a dedicated JPG under assets/, is registered in pubspec.yaml, and is connected to its relevant page/card. Replace the JPG file while preserving its filename when the approved photo is available.

## 22 November 2026 — Final Professional Polish Edition (source integration)

- Used the newest supplied `JGARM_CHURCH_WEBSITE(1).zip` as the working source for this round; its original archive integrity test passed before editing.
- Confirmed the newly supplied `1000402767.gif` is byte-for-byte identical to `assets/giphy.gif` in the ZIP and retained the uploaded animation under the project's existing asset filename.
- Corrected both stale `assets/the_ministry.jpg` references to the supplied `assets/the_ministry.png` file.
- Corrected the missing `assets/christ_at_the_centre.jpg` vision-pillar reference to the supplied animated `assets/giphy.gif`.
- Added six requested image slides to the existing homepage carousel, while retaining all four existing announcement slides: the animated dove, Jesus GIF, JGARM church hall, Prayer image, Outreach image, and The Ministry image.
- Kept the carousel's five-second automatic rotation and swipe interaction, and added visible previous/next arrow controls.
- Reduced the permanent banner's displayed width (88% of available width, with a 1120px maximum) while preserving the original image file and keeping the permanent banner separate from the carousel.
- Upgraded the Give page's international-transfer guidance and added a clear official-recipient notice naming Bishop Robinshon Onyango Stanley. WorldRemit, Western Union and MoneyGram buttons open their official transfer pages; donors are instructed to verify the recipient before sending. These provider links do not pre-fill a beneficiary or execute a payment inside the app.
- Updated the image placeholder guide and photo manifest to reflect the final PNG/GIF filenames and slideshow placement.

### Validation for this update
- Original uploaded ZIP integrity: passed (`unzip -t`, no compressed-data errors).
- Uploaded GIF and ZIP GIF checksum comparison: identical.
- All literal Dart asset references: checked; no missing referenced files.
- All `pubspec.yaml` asset declarations: checked; no missing declared files.
- All six requested slideshow images: present, registered and referenced by the carousel.
- Dart delimiter scan: passed for the project's Dart source file.
- Flutter/Dart SDK is not installed in this packaging environment. A Flutter compile, `flutter analyze`, FlutLab import, and mobile/desktop runtime test therefore remain outstanding and must be completed in FlutLab before publication.
